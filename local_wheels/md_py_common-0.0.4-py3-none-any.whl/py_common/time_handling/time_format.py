from enum import Enum


class TimeFormat(Enum):
	Dynamic = 'Dynamic'
	HMS = 'HMS'
	MS = 'MS'
	S = 'S'
